<?php
namespace MBTM;

class Storage extends \RWMB_Base_Storage {
	protected $object_type = 'term';
}
